/*
 * File:   IOs.c
 * Author: samiu
 *
 * Created on September 20, 2024, 2:39 PM
 */

#define PB1 PORTAbits.RA2   // Push button 1
#define PB2 PORTBbits.RB4   // Push button 2
#define PB3 PORTAbits.RA4   // Push button 3

#include <xc.h>
#include "IOs.h"

void IOinit(void) {
    AD1PCFG = 0xFFFF; /* keep this line as it sets I/O pins that can also be analog to be digital */
    TRISAbits.TRISA2 = 1; //configuring as input for PB1
    TRISBbits.TRISB4 = 1; //RB4 inp for PB2
    TRISAbits.TRISA4 = 1; //RA4 inp for PB3
    TRISBbits.TRISB8 = 0; //configuring RB5 as OUTPUT for LED
    
    CNPU1bits.CN0PUE = 1;   // enable internal pull-up for PB1
   
    CNPU1bits.CN1PUE = 1;   // enable internal pull-up for PB2
   
    CNPU2bits.CN30PUE = 1;  // enable internal pull-up for PB3
}

void IOCheck(void){
    int pb1 = !PB1;
    int pb2 = !PB2;
    int pb3 = !PB3;
    
        //only requires checks for 2+ or no buttons pressed because those are the
        //only states where previously established delays must be overridden

}
