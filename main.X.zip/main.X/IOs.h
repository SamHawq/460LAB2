#ifndef IOS_H
#define IOS_H

#include <xc.h>

// Function declarations
void IOinit(void);
void IOCheck(void);

#endif // IOS_H