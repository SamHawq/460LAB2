#ifndef CHANGECLK_H
#define CHANGECLK_H

#include <xc.h>

// Function declarations
void newClk(unsigned int clkval);

#endif // CHANGECLK_H